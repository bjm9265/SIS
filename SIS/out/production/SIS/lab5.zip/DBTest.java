import java.util.HashMap;

public class DBTest extends Object {
    static CourseDB courseDB;
    static UserDB userDB;
    private static HashMap<Integer, Course> courses;
    private static HashMap<String, User> users;
}
