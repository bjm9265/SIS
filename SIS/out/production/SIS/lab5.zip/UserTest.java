import java.util.Comparator;

public class UserTest extends Object {
    static Student[] students;
    static Professor[] professors;
    static Comparator<Course> compStu;
    static Comparator<Course> compProf;
}
