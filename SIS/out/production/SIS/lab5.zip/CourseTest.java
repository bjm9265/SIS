public class CourseTest extends Object {
    static Course c1;
    static Course c2;
    static Course c3;
    static Course c4;
    static Course[] courses;
    private static String s1;
    private static String s2;
    private static String s3;
}
